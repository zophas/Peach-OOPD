package nl.oopd.peach.entities.Tilemap;

import com.github.hanyaeger.api.scenes.TileMap;

public class ground_Tilemap extends TileMap {
    @Override
    public void setupEntities() {

    }

    @Override
    public int[][] defineMap() {
        return new int[0][];
    }
}
