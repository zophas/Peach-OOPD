package nl.oopd.peach.entities.buttons;

public class PauseButton {
}
